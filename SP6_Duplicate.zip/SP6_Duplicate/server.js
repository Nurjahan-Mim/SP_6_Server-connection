const express = require("express");
const path = require("path");
const bcrypt = require("bcrypt");
const mysql = require("mysql");

const app = express();
const port = 3000;

// Middleware to parse JSON data from requests
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// MySQL database connection
const db = mysql.createConnection({
  host: "localhost", // Your MySQL host
  user: "root", // Your MySQL username
  password: "", // Your MySQL password (leave blank if none)
  database: "userauth", // Your database name
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    process.exit(1); // Exit the application if the database connection fails
  }
  console.log("Connected to the database");
});

// Register Route (for storing hashed password)
app.post("/add-user", (req, res) => {
  const { username, password } = req.body;

  // Hash the password before saving it to the database
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      console.error("Error hashing password:", err);
      return res.status(500).json({ message: "Internal Server Error" });
    }

    // Insert the user into the database with the hashed password
    const query = "INSERT INTO users (username, password) VALUES (?, ?)";
    db.query(query, [username, hashedPassword], (err, results) => {
      if (err) {
        console.error("Error inserting user:", err);
        return res.status(500).json({ message: "Error adding user" });
      }
      res.json({ message: "User added successfully!" });
    });
  });
});

// Login Route (for comparing hashed password)
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  console.log(`Login Attempt: Username: ${username}, Password: ${password}`);

  const query = `SELECT * FROM users WHERE username = ?`;

  db.query(query, [username], (err, results) => {
    if (err) {
      console.error("Database query error:", err);
      return res.status(500).json({ message: "Internal Server Error" });
    }

    if (results.length > 0) {
      const user = results[0];

      // Compare the hashed password from the database with the input password
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error("Error comparing passwords:", err);
          return res.status(500).json({ message: "Error verifying password" });
        }

        if (isMatch) {
          res.json({ message: "Login successful!" });
        } else {
          res.status(401).json({ message: "Invalid username or password!" });
        }
      });
    } else {
      res.status(401).json({ message: "Invalid username or password!" });
    }
  });
});

// 404 handler for undefined routes
app.use((req, res) => {
  res.status(404).send("404: Page Not Found");
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
