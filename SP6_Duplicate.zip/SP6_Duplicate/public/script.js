document.getElementById("loginBtn").addEventListener("click", async () => {
  // Prevent the default form submission
  event.preventDefault();

  // Get the values from the input fields
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Check if both fields are filled
  if (!username || !password) {
    alert("Please fill in both username and password!");
    return;
  }

  try {
    // Send POST request to the server with login credentials
    const response = await fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }), // Send credentials in the request body
    });

    // Parse the response from the server
    const data = await response.json();

    // If the server responds with a successful status
    if (response.ok) {
      alert(data.message); // Show success message
      // You can redirect the user to a different page or clear the form here
      // window.location.href = "/dashboard"; // Example: Redirect after successful login
    } else {
      alert("Login failed! " + data.message); // Show error message if login fails
    }
  } catch (error) {
    // Catch and log any errors that occur during the fetch process
    console.error("Error:", error);
    alert("An error occurred during login. Please try again later.");
  }
});
